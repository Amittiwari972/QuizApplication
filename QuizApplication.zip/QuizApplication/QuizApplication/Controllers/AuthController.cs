﻿using Microsoft.AspNetCore.Mvc;
using QuizApplication.Models;
using System.Linq;
using BCrypt.Net;

namespace QuizApplication.Controllers
{
    public class AuthController : Controller
    {
        private readonly QuizContext _context;

        public AuthController(QuizContext context)
        {
            _context = context;
        }

        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            var user = _context.Users.SingleOrDefault(u => u.Username == username);

            if (user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash))
            {
                HttpContext.Session.SetInt32("UserId", user.Id);
                return RedirectToAction("Index", "Quiz");
            }

            ViewBag.Error = "Invalid username or password.";
            return View();
        }

        public IActionResult Register() => View();

        [HttpPost]
        public IActionResult Register(string username, string password)
        {
            // Check if the username already exists
            if (_context.Users.Any(u => u.Username == username))
            {
                ViewBag.Error = "Username already exists.";
                return View();
            }

            // Hash the password
            string passwordHash = BCrypt.Net.BCrypt.HashPassword(password);

            // Create a new user
            var newUser = new User
            {
                Username = username,
                PasswordHash = passwordHash
            };

            // Save the new user to the database
            _context.Users.Add(newUser);
            _context.SaveChanges();

            ViewBag.Success = "Registration successful. Please log in.";
            return RedirectToAction("Login");
        }
    }
}
