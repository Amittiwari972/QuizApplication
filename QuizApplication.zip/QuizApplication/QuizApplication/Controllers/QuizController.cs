﻿using Microsoft.AspNetCore.Mvc;
using QuizApplication.Models;
using System.Linq;

namespace QuizApplication.Controllers
{
    public class QuizController : Controller
    {
        private readonly QuizContext _context;

        public QuizController(QuizContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var questions = _context.Questions.OrderBy(q => Guid.NewGuid()).ToList();
            return View(questions);
        }

        [HttpPost]
        public IActionResult Submit(int questionId, string selectedOption)
        {
           
            var userId = HttpContext.Session.GetInt32("UserId");

            
            if (userId == null)
                return RedirectToAction("Login", "Auth");

            
            var question = _context.Questions.FirstOrDefault(q => q.Id == questionId);

           
            if (question == null)
                return NotFound("Question not found");

            // Check if the selected option matches the correct option
            bool isCorrect = question.CorrectOption == selectedOption;

            // Create a new quiz result to store the user's answer
            var result = new QuizResult
            {
                UserId = userId.Value,
                QuestionId = questionId,
                SelectedOption = selectedOption,
                IsCorrect = isCorrect
            };

            // Add the result to the QuizResults table and save the changes
            _context.QuizResults.Add(result);
            _context.SaveChanges();

            // Return a JSON response indicating whether the answer is correct or not
            return Json(new { isCorrect });
        }

    }
}
