﻿using Microsoft.EntityFrameworkCore;

namespace QuizApplication.Models
{
    public class QuizContext : DbContext
    {
        public QuizContext(DbContextOptions<QuizContext> options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<QuizResult> QuizResults { get; set; }

        // Override OnModelCreating to seed data
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            
            modelBuilder.Entity<Question>().HasData(
                new Question
                {
                    Id = 1,
                    Text = "What is 2+2?",
                    OptionA = "3",
                    OptionB = "4",
                    OptionC = "5",
                    OptionD = "6",
                    CorrectOption = "B"
                },
                new Question
                {
                    Id = 2,
                    Text = "Capital of France?",
                    OptionA = "Berlin",
                    OptionB = "Madrid",
                    OptionC = "Paris",
                    OptionD = "Rome",
                    CorrectOption = "C"
                }
            );

            
            modelBuilder.Entity<User>().HasData(
                new User
                {
                    Id = 1,
                    Username = "admin",
                    PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin")
                }
            );
        }
    }
}
